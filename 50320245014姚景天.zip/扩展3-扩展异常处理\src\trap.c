#include "defs.h"
#include "trap.h"

extern void trap_vector();

void kernel_trap_init() {
    w_stvec((uint64)trap_vector);
    intr_on();
}
void init_interrupt() { kernel_trap_init(); }

void print_trapframe(struct trapframe *tf) {
    printf("trapframe at %p\n", tf);
    print_regs(&tf->gpr);
    printf("  status   0x%08x\n", tf->status);
    printf("  epc      0x%08x\n", tf->epc);
    printf("  stval    0x%08x\n", tf->stval);
    printf("  cause    0x%08x\n", tf->cause);
}
void print_csr(struct trapframe *tf) {
    printf("  status   0x%x\n", tf->status);
    printf("  epc      0x%x\n", tf->epc);
    printf("  stval    0x%x\n", tf->stval);
    printf("  cause    0x%x\n", tf->cause);
}
void print_regs(struct pushregs *gpr) {
    printf("  zero     0x%x\n", gpr->zero); printf("  ra       0x%x\n", gpr->ra);
    printf("  sp       0x%x\n", gpr->sp);   printf("  gp       0x%x\n", gpr->gp);
    printf("  tp       0x%x\n", gpr->tp);   printf("  t0       0x%x\n", gpr->t0);
    printf("  t1       0x%x\n", gpr->t1);   printf("  t2       0x%x\n", gpr->t2);
    printf("  s0       0x%x\n", gpr->s0);   printf("  s1       0x%x\n", gpr->s1);
    printf("  a0       0x%x\n", gpr->a0);   printf("  a1       0x%x\n", gpr->a1);
    printf("  a2       0x%x\n", gpr->a2);   printf("  a3       0x%x\n", gpr->a3);
    printf("  a4       0x%x\n", gpr->a4);   printf("  a5       0x%x\n", gpr->a5);
    printf("  a6       0x%x\n", gpr->a6);   printf("  a7       0x%x\n", gpr->a7);
    printf("  s2       0x%x\n", gpr->s2);   printf("  s3       0x%x\n", gpr->s3);
    printf("  s4       0x%x\n", gpr->s4);   printf("  s5       0x%x\n", gpr->s5);
    printf("  s6       0x%x\n", gpr->s6);   printf("  s7       0x%x\n", gpr->s7);
    printf("  s8       0x%x\n", gpr->s8);   printf("  s9       0x%x\n", gpr->s9);
    printf("  s10      0x%x\n", gpr->s10);  printf("  s11      0x%x\n", gpr->s11);
    printf("  t3       0x%x\n", gpr->t3);   printf("  t4       0x%x\n", gpr->t4);
    printf("  t5       0x%x\n", gpr->t5);   printf("  t6       0x%x\n", gpr->t6);
}

// ============================================================
//  核心：扩展异常处理 —— 覆盖全部常见异常类型
// ============================================================
void handle_exception(struct trapframe *tf) {
    uint64 cause_code = tf->cause & SCAUSE_MASK_ECODE;

    switch (cause_code) {
        case InstructionMisaligned:
            printf("[Exception %d] Instruction address misaligned! epc=0x%x\n", cause_code, tf->epc);
            break;
        case InstructionAccessFault:
            printf("[Exception %d] Instruction access fault! epc=0x%x\n", cause_code, tf->epc);
            break;
        case IllegalInstruction:
            printf("[Exception %d] Illegal instruction! epc=0x%x\n", cause_code, tf->epc);
            break;
        case Breakpoint:
            printf("[Exception %d] Breakpoint! epc=0x%x\n", cause_code, tf->epc);
            break;
        case LoadMisaligned:
            printf("[Exception %d] Load address misaligned! bad_addr=0x%x\n", cause_code, tf->stval);
            break;
        case LoadAccessFault:
            printf("[Exception %d] Load access fault! bad_addr=0x%x\n", cause_code, tf->stval);
            break;
        case StoreMisaligned:
            printf("[Exception %d] Store address misaligned! bad_addr=0x%x\n", cause_code, tf->stval);
            break;
        case StoreAccessFault:
            printf("[Exception %d] Store access fault! bad_addr=0x%x\n", cause_code, tf->stval);
            break;
        case SupervisorEnvCall:
            printf("[Exception %d] Supervisor ecall! epc=0x%x\n", cause_code, tf->epc);
            break;
        case InstructionPageFault:
            printf("[Exception %d] Instruction page fault! epc=0x%x\n", cause_code, tf->epc);
            break;
        case LoadPageFault:
            printf("[Exception %d] Load page fault! bad_addr=0x%x\n", cause_code, tf->stval);
            break;
        case StorePageFault:
            printf("[Exception %d] Store page fault! bad_addr=0x%x\n", cause_code, tf->stval);
            break;
        default:
            printf("[Exception %d] Unknown exception! epc=0x%x\n", cause_code, tf->epc);
            print_csr(tf);
            break;
    }

    // 跳过触发异常的指令
    tf->epc = tf->epc + 4;
}

// 中断处理（简单版，未扩展）
void handle_interrupt(struct trapframe *tf) {
    uint64 cause_code = tf->cause & SCAUSE_MASK_ECODE;
    printf("[Interrupt] Code=%d\n", cause_code);
}

static inline void trap_handler(struct trapframe *tf) {
    if (tf->cause & SCAUSE_MASK_INTERRUPT)
        handle_interrupt(tf);
    else
        handle_exception(tf);
}

void trap(struct trapframe *tf) { trap_handler(tf); }
