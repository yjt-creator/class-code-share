#ifndef TRAP_H
#define TRAP_H
#include "defs.h"
#include "types.h"

struct pushregs {
    uintptr zero;  uintptr ra;    uintptr sp;    uintptr gp;
    uintptr tp;    uintptr t0;    uintptr t1;    uintptr t2;
    uintptr s0;    uintptr s1;    uintptr a0;    uintptr a1;
    uintptr a2;    uintptr a3;    uintptr a4;    uintptr a5;
    uintptr a6;    uintptr a7;    uintptr s2;    uintptr s3;
    uintptr s4;    uintptr s5;    uintptr s6;    uintptr s7;
    uintptr s8;    uintptr s9;    uintptr s10;   uintptr s11;
    uintptr t3;    uintptr t4;    uintptr t5;    uintptr t6;
};

struct trapframe {
    struct pushregs gpr;
    uintptr status;
    uintptr epc;
    uintptr stval;
    uintptr cause;
};

void kernel_trap_init(void);
void init_interrupt(void);
void print_trapframe(struct trapframe *tf);
void print_csr(struct trapframe *tf);
void print_regs(struct pushregs *gpr);
void handle_interrupt(struct trapframe *tf);
void handle_exception(struct trapframe *tf);
void trap(struct trapframe *tf);
void uart_init(void);
void plic_init(void);

enum Exception {
    InstructionMisaligned = 0, InstructionAccessFault = 1,
    IllegalInstruction = 2, Breakpoint = 3,
    LoadMisaligned = 4, LoadAccessFault = 5,
    StoreMisaligned = 6, StoreAccessFault = 7,
    UserEnvCall = 8, SupervisorEnvCall = 9, MachineEnvCall = 11,
    InstructionPageFault = 12, LoadPageFault = 13, StorePageFault = 15,
};

enum Interrupt {
    UserSoft = 0, SupervisorSoft,
    UserTimer = 4, SupervisorTimer,
    UserExternal = 8, SupervisorExternal,
};

#endif
