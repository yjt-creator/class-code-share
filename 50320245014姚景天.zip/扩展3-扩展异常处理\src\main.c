#include "print.h"
#include "trap.h"

void test_breakpoint() {
    printf("\n--- [Test 1] Breakpoint (Cause=3) ---\n");
    // 用 .word 强制 4 字节 ebreak，避免 RV64C 压缩为 2 字节 c.ebreak
    asm volatile(".word 0x00100073");
    printf("OK! Returned from breakpoint.\n");
}

void main(void) {
    printf("RISC-V Bootloader\n");
    printf("Hello XOS!\n");
    printf("\n========== Extension 3: Extended Exception Handling ==========\n");

    init_interrupt();

    // 仅测试 OpenSBI 已委托到 S 模式的异常（Breakpoint）
    test_breakpoint();

    printf("\n========== Exception Test Passed! ==========\n");
    while (1) {}
}
