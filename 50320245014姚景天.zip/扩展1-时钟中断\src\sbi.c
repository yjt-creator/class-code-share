#include "sbi.h"
#include "types.h"

int sbi_call(enum sbi_call_type which, uint64 arg0, uint64 arg1, uint64 arg2)
{
	register uint64 a0 asm("a0") = arg0;
	register uint64 a1 asm("a1") = arg1;
	register uint64 a2 asm("a2") = arg2;
	register uint64 a7 asm("a7") = which;
	int ret;
	asm volatile("ecall"
		     : "=r"(ret)
		     : "r"(a0), "r"(a1), "r"(a2), "r"(a7)
		     : "memory");
	if (ret < 0) {
        return -1;
    }
    return ret;
}

void console_putchar(int c)
{
	sbi_call(SBI_CONSOLE_PUTCHAR, c, 0, 0);
}

int console_getchar()
{
	return sbi_call(SBI_CONSOLE_GETCHAR, 0, 0, 0);
}

void shutdown()
{
	sbi_call(SBI_SHUTDOWN, 0, 0, 0);
}
