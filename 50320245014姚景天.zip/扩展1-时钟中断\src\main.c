#include "print.h"
#include "trap.h"

void main(void) {
    printf("RISC-V Bootloader\n");
    printf("Hello XOS!\n");
    printf("\n=== Extension 1: Clock Interrupt ===\n");

    init_interrupt();

    printf("CSR dump after init:\n");
    printf("  sstatus = 0x%x\n", r_sstatus());
    printf("  sie     = 0x%x\n", r_sie());
    printf("  sip     = 0x%x\n", r_sip());
    printf("  stvec   = 0x%x\n", r_stvec());

    uint64 first_tick = r_time() + 10000000ULL;
    printf("r_time() = 0x%x\n", r_time());
    printf("Setting timer...\n");
    sbi_set_timer(first_tick);
    printf("Timer set. Waiting...\n\n");

    while (1) {
        asm volatile("wfi");
    }
}
