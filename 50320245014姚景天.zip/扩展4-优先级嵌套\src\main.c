#include "print.h"
#include "trap.h"

void main(void) {
    printf("RISC-V Bootloader\n");
    printf("Hello XOS!\n");
    printf("\n========== Extension 4: Interrupt Priority & Nesting ==========\n");

    // 初始化（同时使能时钟中断和外部中断）
    init_interrupt();
    uart_init();
    plic_init();

    // 启动时钟中断
    sbi_set_timer(r_time() + 10000000ULL);

    printf("System ready. Priority order: External(3) > Timer(2) > Software(1)\n");
    printf("- Timer interrupts fire every ~0.1 seconds\n");
    printf("- Press keys for UART interrupts (higher priority!)\n");
    printf("- Observe: UART can interrupt timer processing (nesting)\n\n");

    while (1) {
        // 等待中断，观察嵌套行为：
        // 在计时器中断处理期间按键盘 -> UART 中断（优先级3）会打断计时器（优先级2）
    }
}
