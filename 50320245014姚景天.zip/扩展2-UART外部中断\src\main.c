#include "print.h"
#include "trap.h"

void main(void) {
    printf("RISC-V Bootloader\n");
    printf("Hello XOS!\n");
    printf("\n========== Extension 2: UART External Interrupt ==========\n");

    init_interrupt();
    uart_init();
    plic_init();
    printf("UART and PLIC initialized.\n");
    printf("Press keys in console to trigger UART interrupts...\n");
    printf("(Each keypress prints the character and ASCII code)\n\n");

    while (1) {}
}
