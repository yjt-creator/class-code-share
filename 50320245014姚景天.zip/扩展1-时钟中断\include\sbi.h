#ifndef SBI_H
#define SBI_H

#include "types.h"

enum sbi_call_type {
    SBI_SET_TIMER = 0,
    SBI_CONSOLE_PUTCHAR = 1,
    SBI_CONSOLE_GETCHAR = 2,
    SBI_CLEAR_IPI = 3,
    SBI_SEND_IPI = 4,
    SBI_REMOTE_FENCE_I = 5,
    SBI_REMOTE_SFENCE_VMA = 6,
    SBI_REMOTE_SFENCE_VMA_ASID = 7,
    SBI_SHUTDOWN = 8
};

int sbi_call(enum sbi_call_type which, uint64 arg0, uint64 arg1, uint64 arg2);
void console_putchar(int);
int console_getchar();
void shutdown();

#endif
