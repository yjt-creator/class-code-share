#include "defs.h"
#include "trap.h"

extern void trap_vector();

// 当前正在处理的中断优先级（全局变量，用于嵌套控制）
int current_interrupt_priority = PRIO_NONE;

void sbi_set_timer(uint64 stime_value) {
    sbi_call(SBI_SET_TIMER, stime_value, 0, 0);
}

void uart_init() {
    UART_REG(UART_IER) = 0x00;
    UART_REG(UART_FCR) = 0x01;
    UART_REG(UART_LCR) = 0x03;
    UART_REG(UART_IER) = 0x01;
}

void plic_init() {
    PLIC_PRIORITY(UART_IRQ_NUM) = PRIO_EXTERNAL;
    PLIC_ENABLE(UART_IRQ_NUM) |= PLIC_ENABLE_MASK(UART_IRQ_NUM);
    PLIC_THRESHOLD_REG = 0;
}

void kernel_trap_init() {
    w_stvec((uint64)trap_vector);
    w_sie(r_sie() | SIE_STIE | SIE_SEIE);
    intr_on();
}
void init_interrupt() { kernel_trap_init(); }

void print_trapframe(struct trapframe *tf) {
    printf("trapframe at %p\n", tf);
    print_regs(&tf->gpr);
    printf("  status   0x%08x\n", tf->status);
    printf("  epc      0x%08x\n", tf->epc);
    printf("  stval    0x%08x\n", tf->stval);
    printf("  cause    0x%08x\n", tf->cause);
}
void print_csr(struct trapframe *tf) {
    printf("  status   0x%x\n", tf->status);
    printf("  epc      0x%x\n", tf->epc);
    printf("  stval    0x%x\n", tf->stval);
    printf("  cause    0x%x\n", tf->cause);
}
void print_regs(struct pushregs *gpr) {
    printf("  zero     0x%x\n", gpr->zero); printf("  ra       0x%x\n", gpr->ra);
    printf("  sp       0x%x\n", gpr->sp);   printf("  gp       0x%x\n", gpr->gp);
    printf("  tp       0x%x\n", gpr->tp);   printf("  t0       0x%x\n", gpr->t0);
    printf("  t1       0x%x\n", gpr->t1);   printf("  t2       0x%x\n", gpr->t2);
    printf("  s0       0x%x\n", gpr->s0);   printf("  s1       0x%x\n", gpr->s1);
    printf("  a0       0x%x\n", gpr->a0);   printf("  a1       0x%x\n", gpr->a1);
    printf("  a2       0x%x\n", gpr->a2);   printf("  a3       0x%x\n", gpr->a3);
    printf("  a4       0x%x\n", gpr->a4);   printf("  a5       0x%x\n", gpr->a5);
    printf("  a6       0x%x\n", gpr->a6);   printf("  a7       0x%x\n", gpr->a7);
    printf("  s2       0x%x\n", gpr->s2);   printf("  s3       0x%x\n", gpr->s3);
    printf("  s4       0x%x\n", gpr->s4);   printf("  s5       0x%x\n", gpr->s5);
    printf("  s6       0x%x\n", gpr->s6);   printf("  s7       0x%x\n", gpr->s7);
    printf("  s8       0x%x\n", gpr->s8);   printf("  s9       0x%x\n", gpr->s9);
    printf("  s10      0x%x\n", gpr->s10);  printf("  s11      0x%x\n", gpr->s11);
    printf("  t3       0x%x\n", gpr->t3);   printf("  t4       0x%x\n", gpr->t4);
    printf("  t5       0x%x\n", gpr->t5);   printf("  t6       0x%x\n", gpr->t6);
}

// ============================================================
//  异常处理
// ============================================================
void handle_exception(struct trapframe *tf) {
    uint64 cause_code = tf->cause & SCAUSE_MASK_ECODE;
    switch (cause_code) {
        case IllegalInstruction:
            printf("[Exception %d] Illegal instruction!\n", cause_code); break;
        case Breakpoint:
            printf("[Exception %d] Breakpoint!\n", cause_code); break;
        case StoreAccessFault:
            printf("[Exception %d] Store access fault!\n", cause_code); break;
        case SupervisorEnvCall:
            printf("[Exception %d] Supervisor ecall!\n", cause_code); break;
        default:
            printf("[Exception %d] Cause=%d\n", cause_code, cause_code); break;
    }
    tf->epc = tf->epc + 4;
}

// ============================================================
//  中断处理（核心：优先级嵌套）
// ============================================================
void handle_interrupt(struct trapframe *tf) {
    uint64 cause_code = tf->cause & SCAUSE_MASK_ECODE;
    int cur_prio = PRIO_NONE;

    switch (cause_code) {
        case SupervisorSoft:
            cur_prio = PRIO_SOFTWARE;
            printf("[PRIO %d] Software interrupt!\n", cur_prio);
            w_sip(r_sip() & ~SIE_SSIE);
            break;

        case SupervisorTimer: {
            cur_prio = PRIO_TIMER;
            static int tick = 0;
            tick++;
            printf("\n[PRIO %d] ==== Timer Tick #%d ====\n", cur_prio, tick);

            // 模拟耗时处理：打印10次，每次之间可能被高优先级中断打断
            for (int i = 0; i < 5; i++) {
                printf("[PRIO %d]   Timer working... %d/5\n", cur_prio, i + 1);
                // 故意加一段忙等待，给外部中断（按键）创造嵌套机会
                for (volatile int j = 0; j < 100000; j++);
            }

            printf("[PRIO %d] ==== Timer Tick #%d DONE ====\n\n", cur_prio, tick);
            uint64 next = r_time() + 10000000ULL;
            sbi_set_timer(next);
            break;
        }

        case SupervisorExternal: {
            cur_prio = PRIO_EXTERNAL;
            uint32 irq = PLIC_CLAIM_REG;

            if (irq == UART_IRQ_NUM) {
                while (UART_REG(UART_LSR) & UART_LSR_RX_READY) {
                    char c = UART_REG(UART_RHR);
                    printf("[PRIO %d] >>> UART Key: '%c' (0x%x) <<<\n",
                           cur_prio, c, (unsigned char)c);
                }
            } else if (irq != 0) {
                printf("[PRIO %d] Unknown external irq=%d\n", cur_prio, irq);
            }
            PLIC_COMPLETE_REG = irq;
            break;
        }

        default:
            printf("[Interrupt] Unknown! Code=%d\n", cause_code);
            break;
    }
}

// ============================================================
//  Trap 分发 —— 核心：优先级嵌套控制
// ============================================================
static inline void trap_handler(struct trapframe *tf) {
    if (tf->cause & SCAUSE_MASK_INTERRUPT) {
        uint64 cause_code = tf->cause & SCAUSE_MASK_ECODE;

        // 判断新中断的优先级
        int incoming_prio = PRIO_NONE;
        if (cause_code == SupervisorExternal)
            incoming_prio = PRIO_EXTERNAL;
        else if (cause_code == SupervisorTimer)
            incoming_prio = PRIO_TIMER;
        else
            incoming_prio = PRIO_SOFTWARE;

        // 嵌套控制：低优先级不能打断高优先级
        if (incoming_prio <= current_interrupt_priority) {
            printf("[NEST] Low-prio interrupt (prio=%d) rejected. Current prio=%d\n",
                   incoming_prio, current_interrupt_priority);
            return;
        }

        printf("[NEST] Accept interrupt. Incoming prio=%d, Current prio=%d\n",
               incoming_prio, current_interrupt_priority);

        // 保存旧优先级，设置新优先级
        int prev_prio = current_interrupt_priority;
        current_interrupt_priority = incoming_prio;

        // 暂时关中断，处理当前中断
        intr_off();
        handle_interrupt(tf);

        // 恢复旧优先级
        current_interrupt_priority = prev_prio;
        printf("[NEST] Restored priority to %d\n", prev_prio);
    } else {
        handle_exception(tf);
    }
}

void trap(struct trapframe *tf) { trap_handler(tf); }
