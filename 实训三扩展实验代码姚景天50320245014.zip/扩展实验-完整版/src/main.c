#include "print.h"
#include "trap.h"
#include "pmm.h"

void trap_test(void)
{
    printf("*(int *)0x00000000 = 100\n");
    *(int *)0x00000000 = 100;
    printf("Yeah! I'm return back from trap!\n");
}

void test_interrupts(void)
{
    printf("Testing interrupts...\n");
    trap_test();
    printf("Interrupt test completed.\n");
}

void main(void)
{
    printf("RISC-V Bootloader\n");
    printf("Hello XOS!\n");
    printf("\n===== Lab 3 PMM - Full Extension =====\n");
    printf("(Based on Lab 2 Interrupt/Exception + Lab 3 All Extensions)\n");

    // 1. Init interrupt system (Lab 2 Ext 1-4 merged)
    printf("\n>> Initializing interrupt system (Timer+UART+PLIC+Priority Nesting)...\n");
    init_interrupt();
    uart_init();
    plic_init();
    sbi_set_timer(r_time() + 10000000ULL);
    printf("Interrupt system ready: External(prio=3) > Timer(prio=2) > Software(prio=1)\n");

    // 2. Buddy allocator + linked list test (Level 1 + Extension 2)
    printf("\n>> Running buddy allocator basic test (linked-list version)...\n");
    test_pmm();

    // 3. Comprehensive test suite (Extension 3)
    printf("\n>> Running comprehensive test suite...\n");
    test_comprehensive();

    // 4. First-fit allocator test (Extension 4)
    printf("\n>> Running first-fit allocator test...\n");
    test_firstfit();

    printf("\n========================================\n");
    printf("  All tests completed! System entering interrupt wait loop\n");
    printf("  - Press keys to trigger UART external interrupt (prio=3)\n");
    printf("  - Timer interrupt fires every ~0.1 seconds (prio=2)\n");
    printf("  - UART can nest within timer handler (higher priority)\n");
    printf("========================================\n\n");

    while (1) {
        asm volatile("wfi");
    }
}
