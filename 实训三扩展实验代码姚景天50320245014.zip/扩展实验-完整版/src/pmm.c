#include "types.h"
#include "defs.h"
#include "pmm.h"
#include <stdbool.h>

// ============================================================
//  Part 1: Buddy Allocator + Linked List (Level 1 + Extension 2)
// ============================================================
typedef struct {
    bool free;
    bool split;
    int next_free;  // linked list: pointer to next free block
} BlockHeader;

BlockHeader memory[MAX_ORDER][1 << (MAX_ORDER - 1)];
int num_blocks[MAX_ORDER];
int free_list_head[MAX_ORDER];  // linked list: head of free list per order

extern uint64 TEXT_START;
extern uint64 TEXT_END;
extern uint64 DATA_START;
extern uint64 DATA_END;
extern uint64 RODATA_START;
extern uint64 RODATA_END;
extern uint64 BSS_START;
extern uint64 BSS_END;
extern uint64 HEAP_START;
extern uint64 HEAP_SIZE;

static inline uint64 align_page(uint64 address)
{
    uint64 order = (1 << PAGE_SHIFT) - 1;
    return (address + order) & (~order);
}

// ========== Linked List Operations (Extension 2) ==========
static void list_add(int order, int index)
{
    memory[order][index].next_free = free_list_head[order];
    free_list_head[order] = index;
}

static void list_remove(int order, int index)
{
    int *p = &free_list_head[order];
    while (*p != -1) {
        if (*p == index) {
            *p = memory[order][index].next_free;
            memory[order][index].next_free = -1;
            return;
        }
        p = &memory[order][*p].next_free;
    }
}

// ========== Buddy Allocator Init ==========
void pmm_init(void)
{
    uint64 _heap_start_aligned = align_page(HEAP_START);
    uint64 _alloc_start = _heap_start_aligned;
    uint64 _num_pages = 16384;
    uint64 _alloc_end = _alloc_start + (PAGE_SIZE * _num_pages);

    printf("HEAP_START = %p(aligned to %p), HEAP_SIZE = %p,\n"
           "num of pages to be allocated for heap = %d\n",
           HEAP_START, _heap_start_aligned, HEAP_SIZE, _num_pages);
    printf("_alloc_start = %p, _alloc_end = %p\n",
           _alloc_start, _alloc_end);
    printf("TEXT:   %p -> %p\n", TEXT_START, TEXT_END);
    printf("RODATA: %p -> %p\n", RODATA_START, RODATA_END);
    printf("DATA:   %p -> %p\n", DATA_START, DATA_END);
    printf("BSS:    %p -> %p\n", BSS_START, BSS_END);

    uint64 remaining_pages = _num_pages;
    int max_order = 0;
    while ((1ULL << (max_order + 1)) <= remaining_pages && max_order < MAX_ORDER - 1)
        max_order++;

    for (int i = 0; i < MAX_ORDER; i++) {
        num_blocks[i] = 0;
        free_list_head[i] = -1;
    }

    num_blocks[max_order] = 1;
    memory[max_order][0].free = 1;
    memory[max_order][0].split = false;
    list_add(max_order, 0);
}

static uint64 get_block_address(int order, int index)
{
    uint64 base = align_page(HEAP_START);
    uint64 block_size = PAGE_SIZE * (1ULL << order);
    return base + (index * block_size);
}

// ========== Block Allocation (linked list version) ==========
static uint64 alloc_block(int order)
{
    if (order >= MAX_ORDER) return 0;
    if (free_list_head[order] == -1) return 0;

    int idx = free_list_head[order];
    list_remove(order, idx);
    memory[order][idx].free = false;
    return get_block_address(order, idx);
}

// ========== Block Split (Level 1 core) ==========
void split_block(int order)
{
    if (order <= 0) return;

    int idx = free_list_head[order];
    if (idx == -1) return;

    list_remove(order, idx);
    memory[order][idx].split = true;

    int lower_order = order - 1;
    int lower_idx = idx * 2;

    if (lower_idx + 2 > num_blocks[lower_order])
        num_blocks[lower_order] = lower_idx + 2;

    memory[lower_order][lower_idx].free = true;
    memory[lower_order][lower_idx].split = false;
    list_add(lower_order, lower_idx);

    memory[lower_order][lower_idx + 1].free = true;
    memory[lower_order][lower_idx + 1].split = false;
    list_add(lower_order, lower_idx + 1);
}

// ========== Block Merge ==========
void merge_blocks(int order, int index)
{
    while (order < MAX_ORDER - 1) {
        int buddy_index = index ^ 1;
        if (buddy_index >= num_blocks[order] ||
            !memory[order][index].free ||
            !memory[order][buddy_index].free ||
            memory[order][index].split ||
            memory[order][buddy_index].split)
            break;

        list_remove(order, index);
        list_remove(order, buddy_index);
        memory[order][index].free = false;
        memory[order][buddy_index].free = false;

        int higher_order = order + 1;
        int higher_index = index / 2;

        memory[higher_order][higher_index].free = true;
        memory[higher_order][higher_index].split = false;
        list_add(higher_order, higher_index);

        index = higher_index;
        order = higher_order;
    }
}

void free_block(uint64 addr)
{
    uint64 base = align_page(HEAP_START);
    if (addr < base || addr >= base + HEAP_SIZE) return;

    uint64 offset = addr - base;
    int page_number = offset / PAGE_SIZE;

    for (int order = 0; order < MAX_ORDER; order++) {
        int block_size = 1 << order;
        if (page_number % block_size != 0) continue;

        int index = page_number / block_size;
        if (index >= num_blocks[order]) continue;

        if (!memory[order][index].free) {
            memory[order][index].free = true;
            list_add(order, index);
            merge_blocks(order, index);
            return;
        }
    }
}

// ========== Buddy Alloc/Free (Level 1 core) ==========
uint64 pm_alloc_pages(int npages)
{
    if (npages <= 0) return 0;
    int order = 0;
    while ((1 << order) < npages) order++;

    for (int o = order; o < MAX_ORDER; o++) {
        if (free_list_head[o] == -1) continue;
        for (int k = o; k > order; k--)
            split_block(k);
        uint64 addr = alloc_block(order);
        if (addr != 0) return addr;
    }
    return 0;
}

void pm_free_pages(uint64 addr, int npages)
{
    free_block(addr);
}

void print_memory_status(void)
{
    printf("\nMemory Status:\n");
    for (int order = 0; order < MAX_ORDER; ++order) {
        int free_count = 0;
        int curr = free_list_head[order];
        while (curr != -1) {
            free_count++;
            curr = memory[order][curr].next_free;
        }
        printf("Order %d: Total=%d Free=%d\n", order, num_blocks[order], free_count);
    }
}

// ========== Basic Test (Level 1) ==========
void test_pmm(void)
{
    pmm_init();
    printf("\nTesting PMM (Buddy + Linked-List)...\n");
    print_memory_status();

    uint64 addr1 = pm_alloc_pages(1);
    printf("Allocated 1 page at: %p", addr1);
    print_memory_status();

    uint64 addr2 = pm_alloc_pages(2);
    printf("Allocated 2 pages at: %p", addr2);
    print_memory_status();

    uint64 addr3 = pm_alloc_pages(4);
    printf("Allocated 4 pages at: %p", addr3);
    print_memory_status();

    pm_free_pages(addr2, 2);
    printf("Freed 2 pages at: %p", addr2);
    print_memory_status();

    uint64 addr4 = pm_alloc_pages(2);
    printf("Allocated 2 pages at: %p", addr4);
    print_memory_status();

    pm_free_pages(addr1, 1);
    printf("Freed 1 page at: %p", addr1);
    print_memory_status();

    pm_free_pages(addr3, 4);
    printf("Freed 4 pages at: %p", addr3);
    print_memory_status();

    pm_free_pages(addr4, 2);
    printf("Freed 2 pages at: %p", addr4);
    print_memory_status();

    printf("PMM Basic tests completed.\n");
}

// ============================================================
//  Part 2: Comprehensive Test Suite (Extension 3)
// ============================================================
static int test_pass = 0;
static int test_fail = 0;

static void check(int cond, const char *msg)
{
    if (cond) { test_pass++; printf("  [PASS] %s\n", msg); }
    else      { test_fail++; printf("  [FAIL] %s\n", msg); }
}

// Test 1: basic alloc/free flow
static void test_basic(void)
{
    printf("\n--- Comprehensive Test 1: Basic alloc/free ---\n");
    pmm_init();
    uint64 a1 = pm_alloc_pages(1);
    uint64 a2 = pm_alloc_pages(2);
    uint64 a3 = pm_alloc_pages(4);

    check(a1 != 0, "alloc 1 page");
    check(a2 != 0, "alloc 2 pages");
    check(a3 != 0, "alloc 4 pages");
    check(a1 % PAGE_SIZE == 0, "1-page addr aligned");
    check(a2 % PAGE_SIZE == 0, "2-page addr aligned");

    pm_free_pages(a2, 2);
    uint64 a4 = pm_alloc_pages(2);
    check(a4 == a2, "re-alloc 2 pages returns same addr");

    pm_free_pages(a1, 1);
    pm_free_pages(a3, 4);
    pm_free_pages(a4, 2);
}

// Test 2: boundary conditions
static void test_boundary(void)
{
    printf("\n--- Comprehensive Test 2: Boundary conditions ---\n");
    pmm_init();

    uint64 a0 = pm_alloc_pages(0);
    check(a0 == 0, "0-page request returns 0");

    uint64 a_huge = pm_alloc_pages(20000);
    check(a_huge == 0, "oversized request returns 0");

    int count = 0;
    while (1) {
        uint64 a = pm_alloc_pages(1);
        if (a == 0) break;
        count++;
    }
    printf("  Allocated %d single pages before exhaustion\n", count);
    check(count > 100, "can allocate many small blocks");
}

// Test 3: random alloc/free sequence
static void test_random(void)
{
    printf("\n--- Comprehensive Test 3: Random alloc/free sequence ---\n");
    pmm_init();

    uint64 addrs[20];
    int sizes[20];
    int n = 0;

    int reqs[] = {1, 3, 2, 5, 1, 8, 2, 4, 1, 7};
    for (int i = 0; i < 10; i++) {
        addrs[n] = pm_alloc_pages(reqs[i]);
        if (addrs[n] != 0) sizes[n] = reqs[i];
        n++;
    }

    pm_free_pages(addrs[0], sizes[0]);
    pm_free_pages(addrs[2], sizes[2]);
    pm_free_pages(addrs[5], sizes[5]);
    pm_free_pages(addrs[7], sizes[7]);
    addrs[0] = addrs[2] = addrs[5] = addrs[7] = 0;

    int more[] = {2, 4, 1, 3};
    for (int i = 0; i < 4; i++) {
        uint64 a = pm_alloc_pages(more[i]);
        if (a != 0) {
            addrs[n] = a; sizes[n] = more[i]; n++;
        }
    }

    for (int i = 0; i < n; i++) {
        if (addrs[i] != 0)
            pm_free_pages(addrs[i], sizes[i]);
    }

    check(1, "random sequence completed without crash");
}

// Test 4: address consistency after free re-alloc
static void test_reuse(void)
{
    printf("\n--- Comprehensive Test 4: Address reuse after free ---\n");
    pmm_init();

    uint64 a1 = pm_alloc_pages(8);
    check(a1 != 0, "alloc 8 pages");
    pm_free_pages(a1, 8);

    uint64 a2 = pm_alloc_pages(8);
    check(a2 == a1, "re-alloc 8 pages: same address");
    pm_free_pages(a2, 8);
}

// Test 5: cover all orders
static void test_all_orders(void)
{
    printf("\n--- Comprehensive Test 5: Cover all orders ---\n");
    pmm_init();

    uint64 addrs[10];
    for (int i = 0; i < 7; i++) {
        int pages = 1 << i;
        addrs[i] = pm_alloc_pages(pages);
        printf("  Order %d (%d pages) addr: %p\n", i, pages, addrs[i]);
    }
    for (int i = 0; i < 7; i++) {
        check(addrs[i] != 0, "multi-order alloc");
        pm_free_pages(addrs[i], 1 << i);
    }
}

void test_comprehensive(void)
{
    test_pass = 0;
    test_fail = 0;

    printf("\n========================================\n");
    printf("  Comprehensive Test Suite (Extension 3)\n");
    printf("========================================\n");

    test_basic();
    test_boundary();
    test_random();
    test_reuse();
    test_all_orders();

    printf("\n========== Comprehensive Tests: %d passed, %d failed ==========\n",
           test_pass, test_fail);
}

// ============================================================
//  Part 3: First-Fit Allocator (Extension 4)
// ============================================================
typedef struct FreeRange {
    uint64 size;
    struct FreeRange* next;
} FreeRange;

static FreeRange* free_list;
static uint64 heap_base;
static uint64 heap_end;

static inline uint64 align_up(uint64 x, uint64 align)
{
    return (x + align - 1) & ~(align - 1);
}

void ff_init(void)
{
    heap_base = align_page(HEAP_START);
    heap_end = heap_base + 16384 * PAGE_SIZE;

    printf("\n========== First-Fit Allocator Init ==========\n");
    printf("HEAP_START = %p(aligned to %p), HEAP_SIZE = %p\n",
           HEAP_START, heap_base, HEAP_SIZE);
    printf("heap_base = %p, heap_end = %p\n", heap_base, heap_end);

    free_list = (FreeRange*)heap_base;
    free_list->size = heap_end - heap_base;
    free_list->next = 0;
}

    // Insert in address order, merge adjacent ranges
static void free_insert(FreeRange* node)
{
    FreeRange *prev = 0, *curr = free_list;

    while (curr && (uint64)curr < (uint64)node) {
        prev = curr;
        curr = curr->next;
    }

    if (prev && (uint64)prev + prev->size == (uint64)node) {
        prev->size += node->size;
        node = prev;
    } else if (prev) {
        prev->next = node;
    } else {
        free_list = node;
    }

    if (curr && (uint64)node + node->size == (uint64)curr) {
        node->size += curr->size;
        node->next = curr->next;
    } else {
        node->next = curr;
    }
}

uint64 ff_alloc_pages(int npages)
{
    if (npages <= 0) return 0;

    uint64 need = (uint64)npages * PAGE_SIZE;
    need = align_up(need, 8);

    FreeRange *prev = 0, *curr = free_list;
    while (curr) {
        if (curr->size >= need) {
            uint64 alloc_addr = (uint64)curr;

            if (curr->size >= need + sizeof(FreeRange) + 8) {
                FreeRange* remain = (FreeRange*)(alloc_addr + need);
                remain->size = curr->size - need;
                remain->next = curr->next;

                if (prev)
                    prev->next = remain;
                else
                    free_list = remain;
            } else {
                if (prev)
                    prev->next = curr->next;
                else
                    free_list = curr->next;
            }

            return alloc_addr;
        }
        prev = curr;
        curr = curr->next;
    }
    return 0;
}

void ff_free_pages(uint64 addr, int npages)
{
    if (npages <= 0 || addr < heap_base || addr >= heap_end) return;

    uint64 size = (uint64)npages * PAGE_SIZE;
    size = align_up(size, 8);

    FreeRange* node = (FreeRange*)addr;
    node->size = size;
    free_insert(node);
}

static void ff_print_status(void)
{
    printf("\nFirst-Fit Memory Status:\n");
    FreeRange* curr = free_list;
    uint64 total_free = 0;
    int count = 0;
    while (curr) {
        total_free += curr->size;
        count++;
        curr = curr->next;
    }
    printf("Free ranges: %d, Total free bytes: %d (%d pages)\n",
           count, total_free, total_free / PAGE_SIZE);
}

void test_firstfit(void)
{
    int ff_pass = 0, ff_fail = 0;
#define FF_CHECK(cond, msg) \
    if (cond) { ff_pass++; printf("  [PASS] %s\n", msg); } \
    else      { ff_fail++; printf("  [FAIL] %s\n", msg); }

    printf("\n========================================\n");
    printf("  First-Fit Allocator Test (Extension 4)\n");
    printf("========================================\n");

    ff_init();

    uint64 a1 = ff_alloc_pages(1);
    uint64 a2 = ff_alloc_pages(2);
    uint64 a3 = ff_alloc_pages(4);
    printf("Alloc 1p: %p, 2p: %p, 4p: %p\n", a1, a2, a3);

    FF_CHECK(a1 != 0 && a2 != 0 && a3 != 0, "basic alloc");
    FF_CHECK(a2 == a1 + 1 * PAGE_SIZE, "alloc 2p right after 1p");
    FF_CHECK(a3 == a2 + 2 * PAGE_SIZE, "alloc 4p right after 2p");

    ff_print_status();

    ff_free_pages(a2, 2);
    printf("Freed 2p at %p\n", a2);
    ff_print_status();

    uint64 a4 = ff_alloc_pages(2);
    printf("Re-alloc 2p at %p\n", a4);
    FF_CHECK(a4 == a2, "re-alloc returns same address (first-fit)");

    uint64 a5 = ff_alloc_pages(8);
    FF_CHECK(a5 != 0, "alloc larger block");

    ff_free_pages(a1, 1);
    ff_free_pages(a3, 4);
    ff_free_pages(a4, 2);
    ff_free_pages(a5, 8);

    ff_print_status();
    printf("\n========== First-Fit Tests: %d passed, %d failed ==========\n",
           ff_pass, ff_fail);
#undef FF_CHECK
}
