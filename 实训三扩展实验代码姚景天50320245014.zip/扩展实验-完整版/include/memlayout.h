#ifndef __KERN_MM_MEMLAYOUT_H__
#define __KERN_MM_MEMLAYOUT_H__

#define KERNEL_BASE          0x80200000
#define KERNEL_END           0x88000000

#define RAM_SIZE             0x7E00000

#endif /* __KERN_MM_MEMLAYOUT_H__ */
