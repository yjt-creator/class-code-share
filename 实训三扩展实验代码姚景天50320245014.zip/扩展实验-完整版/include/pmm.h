#ifndef PMM_H
#define PMM_H

#include "types.h"
#include "memlayout.h"

// 物理内存管理相关的常量和宏定义
#define MAX_ORDER 10 // 最大块大小为 2^10 * PAGE_SIZE = 4MB
#define PAGE_SHIFT 12 // 4KB page size (2^12)
#define PAGE_SIZE (1 << PAGE_SHIFT) // 页面大小
#define MIN_BLOCK_SIZE (1 << PAGE_SHIFT)// 最小块大小

// ========== 伙伴算法接口 ==========
void pmm_init(void);
uint64 pm_alloc_pages(int npages);
void pm_free_pages(uint64 addr, int npages);
void test_pmm(void);
void test_comprehensive(void);

// ========== 首次适配分配器接口 (实验三扩展4) ==========
void ff_init(void);
uint64 ff_alloc_pages(int npages);
void ff_free_pages(uint64 addr, int npages);
void test_firstfit(void);

#endif // PMM_H
